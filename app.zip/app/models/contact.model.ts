export interface Contact {
   
    id :string;
    name: string;
    email: string;
    phoneNumber: string;
    birthday: string;
    note:string;

}