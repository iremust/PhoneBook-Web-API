import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { Contact } from 'src/app/models/contact.model';
import { ContactsService } from 'src/app/services/contacts.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {
  confirmBox(id :string){
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })
    swalWithBootstrapButtons.fire({
      
      title:'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        swalWithBootstrapButtons.fire(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        )
        this.deleteContact(id);
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Your contact has not been deleted',
          'error'
        )
      }
    })
  }
  confirmUpdateBox(){
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-secondary'
      },
      buttonsStyling: false
    })
    
    swalWithBootstrapButtons.fire({
      title: 'Are you sure?',
      text: "",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, update it',
      cancelButtonText: 'No, cancel',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        swalWithBootstrapButtons.fire(
          'Updated',
          'Your file has been updated.',
          'success'
        )
        this.updateContact();
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Your contact has not been updated',
          'error'
        )
      }
    })
  }

  contactDetails: Contact={
    id:'',
    name:'',
    email:'',
    phoneNumber:'',
    birthday:'',
    note:'',
   };
  
  constructor(private route: ActivatedRoute,private contactService:
     ContactsService,private router:Router){}

  ngOnInit(): void {
    this.route.paramMap.subscribe({
      next: (params) =>{
        const id= params.get('id');
        
        if(id){
          this.contactService.getContact(id)
          .subscribe({
            next:(response)=>{
              this.contactDetails= response;

            }
          });

        }
      }
    })
  }
  
  updateContact(){
    this.contactService.updateContact(this.contactDetails.id, this.contactDetails)
    .subscribe({
      next:(_response)=>{
        this.router.navigate(['contacts']);
      }
    });
  }

  deleteContact(id:string){
    this.contactService.deleteContact(id)
    .subscribe({
      next:(_response)=>{
        this.router.navigate(['contacts']);
      }
    });
  }


}
